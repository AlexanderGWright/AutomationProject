//Alexander Wright, Automation Coding Project, May 8 2021

//Import needed to run Cucumber BDD tests
import { Given, When, Then } from '@cucumber/cucumber';


//To run the test paste 'npx wdio run wdio.conf.js' into the terminal
//After running the test, paste 'npm  run open-allure' into the terminal to generate and open the Allure report


//Executes the 'Given' step from the feature file
Given(/^I am on the (\w+) page$/, async (page) => {

    //Launches the website to test in Chrome by default. 
    //This url will need to be changed depending on where you store the the website folder
    await browser.url("file:///C:/Users/alwr1/Desktop/Automation%20Coding%20Project%20-%20Alexander%20Wright/Index.html#");
    
});

//Executes the 'When' step from the feature file
When(/^I login with (\w+) and (.+)$/, async (username, password) => {
    
    //Any passed in parms with '[blank]' will replace it's values with an empty string to trigger the websites alerts
    if(username === "[blank]")
    {
        username = "";
    }
    else if(password === "[blank]")
    {
        password = "";
        
    }
    else if(username === "[blank]" && password === "[blank]")
    {
        username = "";
        password = "";
    }

    //Finds the elements by ID and sets their values
    await (await $('#myUsername')).setValue(username);
    await (await $('#myPassword')).setValue(password);

    //Finds the button element by ID and performs a click
    await (await $('#myLogin')).click();
});

//Executes the 'Then' step from the feature file
Then(/^I should see a message saying (.*)$/, (message) => {
   
   //If the passed in message from the feature file's example table is one which the alert displays
   //The browser will assert the alert text matches the message parm and dismisses the alert
    if(message === "Please provide a password!" || message === "Please provide a username!" || message === "Please provide a username and password!")
   {

     expect(browser.getAlertText()).toHaveTextContaining(message);
     browser.acceptAlert();
   }
   else
   {
    
    //Asserts that the login message matches that of the exampke table in the feature file
     expect($('#login-msg')).toHaveTextContaining(message);
   }
});

