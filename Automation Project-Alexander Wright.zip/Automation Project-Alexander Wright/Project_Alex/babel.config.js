//Alexander Wright, Automation Coding Project, May 8 2021

//Config file for babel
module.exports = {
    "presets": [
        [
            "@babel/preset-env",
            {
                "targets": {
                    "node": "14"
                }
            }
        ]
    ]
}
