//Alexander Wright, Automation Coding Project, May 7 2021

//Login info: Username - test Password - password

//Constant variables that get the HTML elements for the login button and error message
const loginButton = document.getElementById("myLogin");
const loginErrorMsg = document.getElementById("login-msg");

//Button click event listner for the login button
loginButton.addEventListener("click", (e) => {
	
	//Constant variables that get the value of HTML text inputs
    const myUsername = document.getElementById("myUsername").value;
    const myPassword = document.getElementById("myPassword").value;
	
	//User is logged in if the username and password is correct
    if (myUsername === "test" && myPassword === "password") 
	{
		location.href = "LoginSuccess.html";
    }
	//If the username and password is empty and alert will display
	else if(myUsername === "" && myPassword === "")
	{
		alert("Please provide a username and password!");
	}
	//If the username is empty and alert will display
	else if(myUsername === "")
	{
		loginErrorMsg.style.opacity = 0;
		
		alert("Please provide a username!");
	}
	//If the password is empty and alert will display
	else if(myPassword === "")
	{
		loginErrorMsg.style.opacity = 0;
		
		alert("Please provide a password!");
	}
	//If the provided username and password is incorrect then an error message will display
	else
	{
		 loginErrorMsg.style.opacity = 1;
	}	
});
